package com.worxfr.common;

public class Const {
    public static String CURRENT_USER = "current_user";
}
